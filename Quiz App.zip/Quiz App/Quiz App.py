from tkinter import *
import random
import sqlite3
import time
from tkinter import messagebox
from winsound import *

#Functionalies

def signUp():
    window.destroy()
    global signUpWindow
    signUpWindow = Tk()
    signUpWindow.title("Sign Up")
    signUpWindow.resizable(0, 0)


    global full_name, user_name, password, country
    full_name = StringVar()
    user_name = StringVar()
    password = StringVar()
    country = StringVar()

    signUpcanvas = Canvas(signUpWindow, width=500, height=450)
    signUpcanvas.grid(column=0, row=1)

    canvasimg = PhotoImage(file="img2.png")
    signUpcanvas.create_image(0, 0, image=canvasimg, anchor=NW)

    signUpFrame = Frame(signUpcanvas, bg="white")
    signUpFrame.place(relwidth=0.8,relheight=0.8,relx=0.1,rely=0.1)

    l1 = Label(signUpFrame, text="Quiz App Sign-Up", font=("Arial Bold", 16),bg='white', fg='red')
    l1.grid(column=1, row=0, pady=20)

    l2 = Label(signUpFrame, text="Full Name",bg='white', font=("Arial Bold", 14))
    l2.grid(column=0, row=4)

    txt1 = Entry(signUpFrame, width=35, textvariable=full_name)
    txt1.grid(column=1, row=4)

    l2 = Label(signUpFrame, text="User Name",bg='white', font=("Arial Bold", 14))
    l2.grid(column=0, row=5)

    txt2 = Entry(signUpFrame, width=35, textvariable=user_name)
    txt2.grid(column=1, row=5)

    l3 = Label(signUpFrame, text="Password",bg='white', font=("Arial Bold", 14))
    l3.grid(column=0, row=6)

    txt3 = Entry(signUpFrame, width=35, textvariable=password)
    txt3.grid(column=1, row=6)

    l4 = Label(signUpFrame, text="Country",bg='white', font=("Arial Bold", 14))
    l4.grid(column=0, row=7)

    txt3 = Entry(signUpFrame, width=35, textvariable=country)
    txt3.grid(column=1, row=7)

    btn1 = Button(signUpFrame, text="Proceed", bg="blue", fg="black", font=("Arial Bold", 16), command=newEntry)
    btn1.grid(column=1, row=8, pady=20)

    btn2 = Button(signUpFrame, text="Already Have Account??", fg="BLUE", font=("Arial Bold", 10), command=login)
    btn2.grid(column=1, row=10)

    signUpWindow.mainloop()



def newEntry():
    if full_name.get() == '' or user_name.get() == '' or password.get() == '' or country.get() == '':
        messagebox.showerror('Required Fields', 'Please include all fields')
        return

    fName= full_name.get()
    uName= user_name.get()
    pwd= password.get()
    coun_try=country.get()

    conn = sqlite3.connect('my_database.db')
    cur = conn.cursor()
    cur.execute('CREATE TABLE IF NOT EXISTS userDetails(FullName text, UserName text,PassWord text,Country text)')
    cur.execute("INSERT INTO userDetails VALUES (?,?,?,?)", (fName, uName, pwd, coun_try))
    conn.commit()
    cur.execute('SELECT * FROM userDetails')
    userData = cur.fetchall()
    conn.close()

    print("Your Data Has Been Recorded, You Can Now Login !!")

    login()


def login():

    def selectDifficulty():
        loginWindow.destroy()

        selectDifficultyWindow = Tk()
        selectDifficultyWindow.title("Select Your Difficulty level")
        selectDifficultyWindow.resizable(0, 0)

        selectDifficultyCanvas = Canvas(selectDifficultyWindow, width=500, height=450)
        selectDifficultyCanvas.pack()
        selectDifficultyimg = PhotoImage(file="img2.png")
        selectDifficultyCanvas.create_image(0, 0, image=selectDifficultyimg, anchor=NW)

        selectDifficultyFrame = Frame(selectDifficultyCanvas, bg="white")
        selectDifficultyFrame.place(relwidth=0.8, relheight=0.8, relx=0.1, rely=0.1)


        l1 = Label(selectDifficultyFrame, text="Select Difficulty Level", font=("Arial Bold", 22), fg='green',
                   bg='white')
        l1.pack(anchor="center")

        rbtn = IntVar()
        rbtn.set(0)

        r1 = Radiobutton(selectDifficultyFrame, text='Easy', font=("Arial Bold", 16), bg="white", value=1, variable=rbtn)
        r1.pack(pady=20, anchor="w")

        r2 = Radiobutton(selectDifficultyFrame, text='Medium', font=("Arial Bold", 16), bg="white", value=2, variable=rbtn)
        r2.pack(pady=20, anchor="w")

        r3 = Radiobutton(selectDifficultyFrame, text='Hard', font=("Arial Bold", 16), bg="white", value=3, variable=rbtn)
        r3.pack(pady=20, anchor="w")

        def chooseLevel():

            x = rbtn.get()
            print(x)
            if x == 1:
                selectDifficultyWindow.destroy()
                easy_fnc()
            elif x == 2:
                selectDifficultyWindow.destroy()
                medium_fnc()

            elif x == 3:
                selectDifficultyWindow.destroy()
                hard_fnc()
            else:
                messagebox.showerror('Select Your Difficulty', 'Please Select any Difficulty Option !!!')




        ptStart = Button(selectDifficultyFrame, text="Press To Start", bg='blue', fg='black', font=('Arial Bold', 18), command=chooseLevel)
        ptStart.pack(pady=20, anchor="center")

        selectDifficultyWindow.mainloop()

    def loginVerify():
        loginCredentials = userData
        if loginUserName.get() == '' or loginPassword.get() == '':
            messagebox.showerror('Required Fields', 'Please include all fields')
            return
        for name, username, password, country in loginCredentials:
            if username == loginUserName.get() and password == loginPassword.get():
                print("Hurrey!!!, Login Successful")
                i = 1
                break

        else:
            print("Login Unsuccessful, Please try again!!!")
            i = 0
        if (i == 1):
            selectDifficulty()


    # login() functionality
    conn = sqlite3.connect('my_database.db')
    cur = conn.cursor()
    conn.commit()
    cur.execute('SELECT * FROM userDetails')
    global userData
    userData = cur.fetchall()
    print("Please Enter Your Credentials")
    signUpWindow.destroy()

    loginWindow = Tk()
    loginWindow.title('Login')
    loginWindow.resizable(0, 0)
    global loginUserName, loginPassword

    loginUserName = StringVar()
    loginPassword= StringVar()

    logincanvas = Canvas(loginWindow, width=500, height=450)
    logincanvas.pack()

    loginCanvasimg = PhotoImage(file="img2.png")
    logincanvas.create_image(0, 0, image=loginCanvasimg, anchor=NW)

    loginFrame = Frame(logincanvas, bg="white")
    loginFrame.place(relwidth=0.8, relheight=0.8, relx=0.1, rely=0.1)


    l1 = Label(loginFrame, text="IOT Quiz Login", font=("Arial Bold", 20), fg='red',bg ='white')
    l1.pack(anchor="center")

    l2 = Label(loginFrame, text="User Name", fg="purple", font=("Arial Bold", 15),bg='white')
    l2.pack(pady=20, anchor="center")

    txt1 = Entry(loginFrame, width=30, textvariable=loginUserName)
    txt1.pack(padx=20,anchor="center")

    l2 = Label(loginFrame, text="Password", fg="purple", font=("Arial Bold", 15),bg='white')
    l2.pack(pady=30, anchor="center")

    txt2 = Entry(loginFrame, width=30, textvariable=loginPassword)
    txt2.pack(padx=20,anchor="center")

    btn = Button(loginFrame, text="Login", bg="blue", fg="black", font=("Arial Bold", 16), command=loginVerify)
    btn.pack(pady= 20,anchor="center")

    loginWindow.mainloop()

def easy_fnc():
    global easyWindow

    easyWindow = Tk()
    easyWindow.title("Select Your Difficulty level")
    easyWindow.resizable(0, 0)

    easyCanvas = Canvas(easyWindow, width=500, height=450)
    easyCanvas.pack()
    easyimg = PhotoImage(file="img2.png")
    easyCanvas.create_image(0, 0, image=easyimg, anchor=NW)

    easyFrame = Frame(easyCanvas, bg="white")
    easyFrame.place(relwidth=0.8, relheight=0.8, relx=0.1, rely=0.1)

    def countDown():
        check = 0
        for k in range(10, 0, -1):

            if k == 1:
                check = -1
            timer.configure(text=k)
            easyFrame.update()
            time.sleep(1)

        timer.configure(text="Times up!")
        if check == -1:
            return (-1)
        else:
            return 0

    global score
    score = 0
    easy_Ques = [
        [
            "Which of the following is the first calculating device?",
            "Abacus",
            "Calculator",
            "Turing Machine",
            "Pascaline"
        ],
        [
            "Who invented mechanical calculator called Pascaline?",
            "Charles Babbage",
            "Blaise Pascal",
            "Alan Turing",
            "Lee De Forest"

        ],
        [
            "Who among the following considered as the 'father of AI'?",
            "Charles Babbage",
            "Lee De Forest",
            "John McCarthy",
            "JP Eckert"
        ],
        [
            "The world's first successful electronic computer?",
            "PARAM",
            "CRAY-1",
            "Pascaline",
            "ENIAC"
        ],
        [
            "Who used the term computer worm for the first time?",
            "John Brunner",
            "Alan Turing",
            "John McCarthy",
            "JP Eckert"
        ]
    ]
    answer = [
        "Abacus",
        "Blaise Pascal",
        "John McCarthy",
        "ENIAC",
        "John Brunner"
    ]
    randonList = ['', 0, 1, 2, 3, 4]
    x = random.choice(randonList[1:])

    ques = Label(easyFrame, text=easy_Ques[x][0], font="calibri 12", bg="white", fg="purple")
    ques.place(relx=0.5, rely=0.2, anchor=CENTER)

    var = StringVar()
    var.set(0)
    a = Radiobutton(easyFrame, text=easy_Ques[x][1], font="calibri 10", value=easy_Ques[x][1], variable=var, bg="white")
    a.place(relx=0.5, rely=0.42, anchor=CENTER)

    b = Radiobutton(easyFrame, text=easy_Ques[x][2], font="calibri 10", value=easy_Ques[x][2], variable=var, bg="white")
    b.place(relx=0.5, rely=0.52, anchor=CENTER)

    c = Radiobutton(easyFrame, text=easy_Ques[x][3], font="calibri 10", value=easy_Ques[x][3], variable=var, bg="white")
    c.place(relx=0.5, rely=0.62, anchor=CENTER)

    d = Radiobutton(easyFrame, text=easy_Ques[x][4], font="calibri 10", value=easy_Ques[x][4], variable=var, bg="white")
    d.place(relx=0.5, rely=0.72, anchor=CENTER)

    randonList.remove(x)

    timer = Label(easyWindow)
    timer.place(relx=0.8, rely=0.82, anchor=CENTER)

    def display():

        if len(randonList) == 1:
            easyWindow.destroy()
            showMark(score)
        if len(randonList) == 2:
            nextQuestion.configure(text='End', command=calc)

        if randonList:
            x = random.choice(randonList[1:])
            ques.configure(text=easy_Ques[x][0])

            a.configure(text=easy_Ques[x][1], value=easy_Ques[x][1])

            b.configure(text=easy_Ques[x][2], value=easy_Ques[x][2])

            c.configure(text=easy_Ques[x][3], value=easy_Ques[x][3])

            d.configure(text=easy_Ques[x][4], value=easy_Ques[x][4])

            randonList.remove(x)
            print(randonList)
            y = countDown()
            if y == -1:
                display()

    def calc():
        global score
        if (var.get() in answer):
            score += 1
        display()

    submit = Button(easyFrame, command=calc, text="Submit",  bg="blue", fg="black", font=('Arial Bold', 16))
    submit.place(relx=0.5, rely=0.82, anchor=CENTER)

    nextQuestion = Button(easyFrame, command=display, text="Next", bg="green", fg="black", font=('Arial Bold', 16))
    nextQuestion.place(relx=0.87, rely=0.82, anchor=CENTER)

    y = countDown()
    if y == -1:
        display()
    easyWindow.mainloop()


def medium_fnc():
    global mediumWindow
    mediumWindow = Tk()
    mediumWindow.title("Select Your Difficulty level")
    mediumWindow.resizable(0, 0)

    mediumCanvas = Canvas(mediumWindow, width=500, height=450)
    mediumCanvas.pack()
    mediumimg = PhotoImage(file="img2.png")
    mediumCanvas.create_image(0, 0, image=mediumimg, anchor=NW)

    mediumFrame = Frame(mediumCanvas, bg="white")
    mediumFrame.place(relwidth=0.8, relheight=0.8, relx=0.1, rely=0.1)

    def countDown():
        check = 0
        for k in range(10, 0, -1):

            if k == 1:
                check = -1
            timer.configure(text=k)
            mediumFrame.update()
            time.sleep(1)

        timer.configure(text="Times up!")
        if check == -1:
            return (-1)
        else:
            return 0

    global score
    score = 0

    mediumQ = [
        [
            "Who had written the first worm for computer?",
            "Robert Tappan",
            "Charles Alderton",
            "George Bangs",
            "William Beldue"
        ],
        [
            "The two of the most commonly used languages for CGI",
            "Perl and C++",
            "Java & C++",
            "C & Java",
            "Perl  & Java"
        ],
        [
            "Which of these is not a programming language?",
            "BASIC",
            "COBOL",
            "BNF",
            "FORTRAN"
        ],
        [
            "What does the command prompt uses?",
            "CLI",
            "GUI ",
            "Text User Interface",
            "None of the above"
        ],
        [
            "Is Python case sensitive when dealing with identifiers?",
            "yes",
            "no",
            "machine dependent",
            "none of the mentioned"
        ],
    ]
    answer = [
        "Robert Tappan Morris Jr",
        "Perl and C++",
        "BNF",
        "CLI (Command Line Interface)",
        "yes"
    ]

    li = ['', 0, 1, 2, 3, 4]
    x = random.choice(li[1:])

    ques = Label(mediumFrame, text=mediumQ[x][0], font="calibri 12", bg="white", fg="purple")
    ques.place(relx=0.5, rely=0.2, anchor=CENTER)

    var = StringVar()
    var.set(0)

    a = Radiobutton(mediumFrame, text=mediumQ[x][1], font="calibri 10", value=mediumQ[x][1], variable=var, bg="white")
    a.place(relx=0.5, rely=0.42, anchor=CENTER)

    b = Radiobutton(mediumFrame, text=mediumQ[x][2], font="calibri 10", value=mediumQ[x][2], variable=var, bg="white")
    b.place(relx=0.5, rely=0.52, anchor=CENTER)

    c = Radiobutton(mediumFrame, text=mediumQ[x][3], font="calibri 10", value=mediumQ[x][3], variable=var, bg="white")
    c.place(relx=0.5, rely=0.62, anchor=CENTER)

    d = Radiobutton(mediumFrame, text=mediumQ[x][4], font="calibri 10", value=mediumQ[x][4], variable=var, bg="white")
    d.place(relx=0.5, rely=0.72, anchor=CENTER)

    li.remove(x)

    timer = Label(mediumWindow)
    timer.place(relx=0.8, rely=0.82, anchor=CENTER)

    def display():

        if len(li) == 1:
            mediumWindow.destroy()
            showMark(score)
        if len(li) == 2:
            nextQuestion.configure(text='End', command=calc)

        if li:
            x = random.choice(li[1:])
            ques.configure(text=mediumQ[x][0])

            a.configure(text=mediumQ[x][1], value=mediumQ[x][1])

            b.configure(text=mediumQ[x][2], value=mediumQ[x][2])

            c.configure(text=mediumQ[x][3], value=mediumQ[x][3])

            d.configure(text=mediumQ[x][4], value=mediumQ[x][4])

            li.remove(x)
            print(li)
            y = countDown()
            if y == -1:
                display()

    def calc():
        global score
        if (var.get() in answer):
            score += 1
        display()

    submit = Button(mediumFrame, command=calc, text="Submit", bg="blue", fg="black", font=('Arial Bold', 16))
    submit.place(relx=0.5, rely=0.82, anchor=CENTER)

    nextQuestion = Button(mediumFrame, command=display, text="Next", bg="green", fg="black", font=('Arial Bold', 16))
    nextQuestion.place(relx=0.87, rely=0.82, anchor=CENTER)

    y = countDown()
    if y == -1:
        display()
    mediumFrame.mainloop()


def hard_fnc():
    global hardWindow
    hardWindow = Tk()
    hardWindow.title("Select Your Difficulty level")
    hardWindow.resizable(0, 0)

    hardCanvas = Canvas(hardWindow, width=500, height=450)
    hardCanvas.pack()
    hardimg = PhotoImage(file="img2.png")
    hardCanvas.create_image(0, 0, image=hardimg, anchor=NW)

    hardFrame = Frame(hardCanvas, bg="white")
    hardFrame.place(relwidth=0.8, relheight=0.8, relx=0.1, rely=0.1)


    def countDown():
        check = 0
        for k in range(10, 0, -1):

            if k == 1:
                check = -1
            timer.configure(text=k)
            hardFrame.update()
            time.sleep(1)

        timer.configure(text="Times up!")
        if check == -1:
            return (-1)
        else:
            return 0

    global score
    score = 0

    hardQ = [
        [
            " Verification is process of ?",
            "Access",
            "Login",
            "Logout",
            "Authentication"
        ],
        [
            "What is the name of first super computer of India ?",
            "Saga 220",
            "PARAM 8000",
            "ENIAC",
            "PARAM 6000"
        ],
        [
            "Which is most common language used in web designing ?",
            "C",
            "C++",
            "PHP",
            "HTML"
        ],
        [
            "Most commonly used language in Android applications ?",
            "C",
            "Php",
            "C++",
            "Java"
        ],
        [
            "Where are saved files stored in computer ?",
            "RAM",
            "Hard disk",
            "Cache",
            "Any of above"
        ]

    ]
    answer = [
        "Authentication",
        "PARAM 8000",
        "HTML",
        "Java",
        "Hard disk"
    ]

    li = ['', 0, 1, 2, 3, 4]
    x = random.choice(li[1:])

    ques = Label(hardFrame, text=hardQ[x][0], font="calibri 12", bg="white", fg="purple")
    ques.place(relx=0.5, rely=0.2, anchor=CENTER)

    var = StringVar()
    var.set(0)

    a = Radiobutton(hardFrame, text=hardQ[x][1], font="calibri 10", value=hardQ[x][1], variable=var, bg="white")
    a.place(relx=0.5, rely=0.42, anchor=CENTER)

    b = Radiobutton(hardFrame, text=hardQ[x][2], font="calibri 10", value=hardQ[x][2], variable=var, bg="white")
    b.place(relx=0.5, rely=0.52, anchor=CENTER)

    c = Radiobutton(hardFrame, text=hardQ[x][3], font="calibri 10", value=hardQ[x][3], variable=var, bg="white")
    c.place(relx=0.5, rely=0.62, anchor=CENTER)

    d = Radiobutton(hardFrame, text=hardQ[x][4], font="calibri 10", value=hardQ[x][4], variable=var, bg="white")
    d.place(relx=0.5, rely=0.72, anchor=CENTER)

    li.remove(x)

    timer = Label(hardWindow)
    timer.place(relx=0.8, rely=0.82, anchor=CENTER)

    def display():

        if len(li) == 1:
            hardWindow.destroy()
            showMark(score)
        if len(li) == 2:
            nextQuestion.configure(text='End', command=calc)

        if li:
            x = random.choice(li[1:])
            ques.configure(text=hardQ[x][0])

            a.configure(text=hardQ[x][1], value=hardQ[x][1])

            b.configure(text=hardQ[x][2], value=hardQ[x][2])

            c.configure(text=hardQ[x][3], value=hardQ[x][3])

            d.configure(text=hardQ[x][4], value=hardQ[x][4])

            li.remove(x)
            print(li)
            y = countDown()
            if y == -1:
                display()

    def calc():
        global score
        if (var.get() in answer):
            score += 1
        display()

    submit = Button(hardFrame, command=calc, text="Submit", bg="blue", fg="black", font=('Arial Bold', 16))
    submit.place(relx=0.5, rely=0.82, anchor=CENTER)

    nextQuestion = Button(hardFrame, command=display, text="Next", bg="green", fg="black", font=('Arial Bold', 16))
    nextQuestion.place(relx=0.87, rely=0.82, anchor=CENTER)

    y = countDown()
    if y == -1:
        display()
    hardWindow.mainloop()



def showMark(mark):
    global markShowWindow
    markShowWindow = Tk()
    markShowWindow.title("Select Your Difficulty level")
    markShowWindow.resizable(0, 0)

    markShowCanvas = Canvas(markShowWindow, width=500, height=450)
    markShowCanvas.pack()
    markShowimg = PhotoImage(file="img2.png")
    markShowCanvas.create_image(0, 0, image=markShowimg, anchor=NW)

    markShowFrame = Frame(markShowCanvas, bg="white")
    markShowFrame.place(relwidth=0.8, relheight=0.8, relx=0.1, rely=0.1)

    st1 = "Your Final Score "
    mlabel = Label(markShowFrame, text=st1, bg="white",fg="blue")
    mlabel.place(relx=0.5, rely=0.2, anchor=CENTER)
    mlabel.config(font=('calibri 40'))

    st = "Total-: " + str(mark)
    mlabel = Label(markShowFrame, text=st, bg="white",fg="red", font=("Arial Bold", 20))
    mlabel.place(relx=0.5, rely=0.4, anchor=CENTER)

    markShowWindow.mainloop()



#StartScreen
global window
window = Tk()
window.title("Enjoy Your Quiz")
window.resizable(0, 0)
window.config(background='#ffffff')

windowcanvas = Canvas(window, width=500, height=450)
windowcanvas.grid(column=0, row=1)

canvasimg = PhotoImage(file="img3.png")
windowcanvas.create_image(0, 0, image=canvasimg, anchor=NW)

signUpFrame = Frame(windowcanvas, bg="white")
signUpFrame.place(relwidth=0.8,relheight=0.8,relx=0.1,rely=0.1)


photo = PhotoImage(file="img11.png")

imageLabel = Label(signUpFrame, image=photo, background='#ffffff')
imageLabel.pack()

button = Button(signUpFrame, text='Start', font=("Arial Bold", 20), bg="blue", fg="black", command=signUp)
button.configure(width=8, height=1, activebackground="red")
button.pack(pady=(0,3))

window.mainloop()

